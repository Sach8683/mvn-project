New changes done by developer

some more changes dondddddddeddd


cccccc

